//
//  main.m
//  Example
//
//  Created by David Beck on 3/2/16.
//  Copyright © 2016 NYTimes. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NYTAppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([NYTAppDelegate class]));
	}
}
