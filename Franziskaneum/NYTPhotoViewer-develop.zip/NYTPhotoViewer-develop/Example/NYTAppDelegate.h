//
//  NYTAppDelegate.h
//  ios-photo-viewer
//
//  Created by CocoaPods on 02/11/2015.
//  Copyright (c) 2014 Brian Capps. All rights reserved.
//

@import UIKit;

@interface NYTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
