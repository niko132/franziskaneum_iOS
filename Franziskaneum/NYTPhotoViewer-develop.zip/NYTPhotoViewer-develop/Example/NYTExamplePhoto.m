//
//  NYTExamplePhoto.m
//  ios-photo-viewer
//
//  Created by Brian Capps on 2/11/15.
//  Copyright (c) 2015 NYTimes. All rights reserved.
//

#import "NYTExamplePhoto.h"

@implementation NYTExamplePhoto

@end
