//
//  NYTViewController.h
//  ios-photo-viewer
//
//  Created by Brian Capps on 02/11/2015.
//  Copyright (c) 2014 Brian Capps. All rights reserved.
//

@import UIKit;

@interface NYTViewController : UIViewController

@end
